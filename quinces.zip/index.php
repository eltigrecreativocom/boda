<?php
// ================== CONFIGURACIÓN BACKEND ==================
session_start();

// Credenciales de administrador (cámbialas por seguridad)
$admin_user = 'admin';
$admin_pass = '1234'; // Cambia esto por una contraseña segura

// Archivo para almacenar confirmaciones
$filename = 'confirmaciones.txt';

// Procesar login
if (isset($_POST['login'])) {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if ($username === $admin_user && $password === $admin_pass) {
        $_SESSION['authenticated'] = true;
        $view_confirmations = true;
    } else {
        $login_error = "Credenciales incorrectas";
    }
}

// Procesar logout
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: '.$_SERVER['PHP_SELF']);
    exit;
}

// Procesar envío de formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nombre'])) {
    $data = [
        date('Y-m-d H:i:s'),
        $_POST['nombre'] ?? '',
        $_POST['email'] ?? '',
        $_POST['asistencia'] ?? '',
        $_POST['mensaje'] ?? ''
    ];
    
    $line = implode(' | ', $data) . PHP_EOL;
    file_put_contents($filename, $line, FILE_APPEND);
    
    // Mostrar alerta de éxito
    echo "<script>alert('¡Confirmación enviada con éxito!');</script>";
}

// Verificar si mostrar confirmaciones
$view_confirmations = isset($_SESSION['authenticated']) && $_SESSION['authenticated'];
$confirmaciones = [];
if ($view_confirmations && file_exists($filename)) {
    $confirmaciones = file($filename, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invitación de XV Años - Briahna Portal</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link
        href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&family=Montserrat:wght@400;500;600;700&family=Playfair+Display:wght@700&display=swap"
        rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>

        /* Estilos adicionales para el panel admin */
        .admin-panel {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.95);
            padding: 40px 20px;
            z-index: 2000;
            display: none;
            overflow-y: auto;
        }
        
        .admin-panel.active {
            display: block;
        }
        
        .close-admin {
            position: absolute;
            top: 20px;
            right: 30px;
            font-size: 30px;
            cursor: pointer;
            color: var(--azul-profundo);
            transition: all 0.3s ease;
        }
        
        .close-admin:hover {
            color: var(--dorado);
            transform: scale(1.2);
        }
        
        .admin-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            border-radius: 10px;
            overflow: hidden;
        }
        
        .admin-table th, .admin-table td {
            border: 1px solid #ddd;
            padding: 12px 15px;
            text-align: left;
        }
        
        .admin-table th {
            background-color: var(--azul-profundo);
            color: white;
        }
        
        .admin-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        
        .admin-table tr:hover {
            background-color: rgba(212, 175, 55, 0.1);
        }
        
        .admin-login {
            max-width: 400px;
            margin: 50px auto;
            padding: 30px;
            background: white;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .admin-login h2 {
            text-align: center;
            margin-bottom: 25px;
            color: var(--azul-profundo);
        }
        
        .admin-link {
            position: fixed;
            bottom: 30px;
            right: 30px;
            background: var(--dorado);
            color: white;
            padding: 12px 20px;
            border-radius: 30px;
            z-index: 1000;
            cursor: pointer;
            box-shadow: 0 6px 15px rgba(0,0,0,0.2);
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .admin-link:hover {
            background: #c19d2d;
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.25);
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .titulo {
                font-size: 3rem;
            }
            
            .tiempo {
                flex-wrap: wrap;
            }
            
            .unidad {
                flex: 1 0 40%;
                margin-bottom: 15px;
            }
            
            .evento {
                width: 100%;
            }
            
            .evento:nth-child(odd) .hora,
            .evento:nth-child(even) .hora {
                position: static;
                display: inline-block;
                margin-bottom: 10px;
            }
            
            .timeline-bar {
                display: none;
            }
        }
    </style>
</head>

<body>
    <!-- Panel de administración -->
    <div class="admin-panel <?= $view_confirmations ? 'active' : '' ?>">
        <div class="close-admin" onclick="document.querySelector('.admin-panel').classList.remove('active')">×</div>
        
        <?php if ($view_confirmations): ?>
            <h2>Confirmaciones Recibidas</h2>
            <?php if (!empty($confirmaciones)): ?>
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Nombre</th>
                            <th>Email</th>
                            <th>Asistencia</th>
                            <th>Mensaje</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($confirmaciones as $linea): ?>
                            <tr>
                                <?php $campos = explode(' | ', $linea); ?>
                                <?php foreach ($campos as $campo): ?>
                                    <td><?= htmlspecialchars($campo) ?></td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No hay confirmaciones aún</p>
            <?php endif; ?>
            <div style="margin-top: 30px; text-align: center;">
                <a href="?logout=1" class="btn-enviar">Cerrar sesión</a>
            </div>
        <?php else: ?>
            <div class="admin-login">
                <h2>Acceso de administración</h2>
                <?php if (isset($login_error)): ?>
                    <p style="color: red; text-align: center; margin-bottom: 20px;"><?= $login_error ?></p>
                <?php endif; ?>
                <form method="POST">
                    <div class="form-group">
                        <label for="username">Usuario:</label>
                        <input type="text" id="username" name="username" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Contraseña:</label>
                        <input type="password" id="password" name="password" required>
                    </div>
                    <button type="submit" name="login" class="btn-enviar">Acceder</button>
                </form>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Enlace para abrir panel admin -->
    <div class="admin-link" onclick="document.querySelector('.admin-panel').classList.add('active')">
        <i class="fas fa-lock"></i> Admin
    </div>

    <!-- Selector de idioma -->
    <div class="language-switcher">
        <button class="lang-btn active" data-lang="es">ES</button>
        <button class="lang-btn" data-lang="en">EN</button>
        <button class="lang-btn" data-lang="fr">FR</button>
    </div>

    <!-- Elementos decorativos -->
    <div class="flores flor1">
        <svg viewBox="0 0 100 100">
            <path fill="var(--azul-profundo)"
                d="M50,20 C60,15 70,20 75,30 C80,40 75,50 65,55 C55,60 45,55 40,45 C35,35 40,25 50,20 Z" />
        </svg>
    </div>
    <div class="flores flor2">
        <svg viewBox="0 0 100 100">
            <path fill="var(--dorado)"
                d="M50,20 C60,15 70,20 75,30 C80,40 75,50 65,55 C55,60 45,55 40,45 C35,35 40,25 50,20 Z" />
        </svg>
    </div>

    <div class="estrellas estrella1">
        <i class="fas fa-star" style="color: var(--dorado);"></i>
    </div>
    <div class="estrellas estrella2">
        <i class="fas fa-star" style="color: var(--azul-profundo);"></i>
    </div>
    <div class="estrellas estrella3">
        <i class="fas fa-star" style="color: var(--azul-suave);"></i>
    </div>

    <div class="corona">
        <i class="fas fa-crown"></i>
    </div>

    <div class="container">
        <header class="fondo1">
            <h1 class="titulo" data-i18n="title">Mis XV Años</h1>
            <p class="subtitulo" data-i18n="subtitle">Te invito a celebrar conmigo este momento único e inolvidable</p>

            <div class="foto-principal">
                <div class="nombre">Briahna Portal</div>
            </div>

            <div class="contador">
                <h2 id="contador-texto" data-i18n="countdown_text">¡Solo faltan!</h2>
                <div class="tiempo">
                    <div class="unidad">
                        <div class="numero" id="dias">00</div>
                        <div class="etiqueta" data-i18n="days">Días</div>
                    </div>
                    <div class="unidad">
                        <div class="numero" id="horas">00</div>
                        <div class="etiqueta" data-i18n="hours">Horas</div>
                    </div>
                    <div class="unidad">
                        <div class="numero" id="minutos">00</div>
                        <div class="etiqueta" data-i18n="minutes">Minutos</div>
                    </div>
                    <div class="unidad">
                        <div class="numero" id="segundos">00</div>
                        <div class="etiqueta" data-i18n="seconds">Segundos</div>
                    </div>
                </div>
            </div>
        </header>

        <main>
            <section id="mensaje-section">
                <img src="fo.jpg" alt="" style="width: 100%;border-radius:20px">
                <br>
                <div class="audio-player" id="audioPlayerContainer">
                    <p>Presiona el ❤ para escuchar mi cancion</p>
                    <button class="play-btn" id="playBtn">
                        <i class="fas fa-heart"></i>
                    </button>
                    <span class="song-title" data-i18n="song_title">Canción: Princesa - Joan Sebastian</span>

                </div>
                <br>
                <h2 data-i18n="message_title">Un Mensaje Especial</h2>
                <div class="mensaje">
                    <p data-i18n="message_1">¡Queridos amigos y familiares!</p>
                    <p data-i18n="message_2">Hace 15 años, nació una bella princesa, enviada a nosotros por Dios para
                        ser criada y moldeada en nuestra posesión más preciada. Los momentos que más esperas en la vida
                        son a menudo soñados, imaginados y tienen que ser construidos. Hoy puedo decirles que uno de
                        nuestros sueños se ha hecho realidad, y lo más importante para mí es que celebren conmigo. ¡en
                        este día tan especial!</p>
                    <p data-i18n="message_3">Con todo mi cariño,</p>
                    <p><strong>Briahna Portal</strong></p>
                    <img src="zapa.jpg" alt="" style="
                    width: 100%;
                    mix-blend-mode: darken;
                    max-width: 210px;
                    margin: auto;
                    ">
                </div>
            </section>
            <img src="f2.jpg" alt="" style="
    width: 100%;
">

            <section id="bendicion-section">
                <h2 data-i18n="blessing_title">Con la Bendición de...</h2>
                <div class="bendicion">
                    <div class="persona">
                        <div class="icono"><i class="fas fa-male"></i></div>
                        <h3 data-i18n="father">Mi Papá</h3>
                        <p>Carlos Mendoza</p>
                    </div>
                    <div class="persona">
                        <div class="icono"><i class="fas fa-female"></i></div>
                        <h3 data-i18n="mother">Mi Mamá</h3>
                        <p>María Fernanda López</p>
                    </div>
                    <div class="persona">
                        <div class="icono"><i class="fas fa-hands-praying"></i></div>
                        <h3 data-i18n="godparents">Mis Padrinos</h3>
                        <p>Roberto y Adriana Sánchez</p>
                    </div>
                </div>
            </section>

            <section id="detalles-section" style="display: none;">
                <h2 data-i18n="event_details">Detalles del Evento</h2>
                <div class="detalles-evento">
                    <div class="detalle">
                        <i class="fas fa-calendar-alt"></i>
                        <h3 data-i18n="date">Fecha</h3>
                        <p id="event-date" data-i18n="date_value">Sábado, 15 de Diciembre de 2024</p>
                    </div>
                    <div class="detalle">
                        <i class="fas fa-clock"></i>
                        <h3 data-i18n="time">Hora</h3>
                        <p data-i18n="ceremony_time">Ceremonia: 18:00 hrs</p>
                        <p data-i18n="reception_time">Recepción: 20:00 hrs</p>
                    </div>
                    <div class="detalle">
                        <i class="fas fa-church"></i>
                        <h3 data-i18n="ceremony">Ceremonia Religiosa</h3>
                        <p data-i18n="ceremony_location">Parroquia de Nuestra Señora de Guadalupe</p>
                        <p data-i18n="ceremony_address">Av. Reforma #456, Ciudad</p>
                    </div>
                    <div class="detalle">
                        <i class="fas fa-glass-cheers"></i>
                        <h3 data-i18n="reception">Recepción</h3>
                        <p data-i18n="reception_location">Salón de Eventos "Jardines del Cielo"</p>
                        <p data-i18n="reception_address">Av. Siempre Viva #123, Ciudad</p>
                    </div>
                </div>
            </section>

            <section id="ubicacion-section">
                <h2 data-i18n="location_title">Ubicación</h2>
                <div class="mapa" id="mapa">
                    <iframe
                        src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d7806.835195327306!2d-77.0643419!3d-11.9455629!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x9105d1d2359f1195%3A0xb137faaa2df84b60!2sAv.%20Universitaria%206683%2C%20Comas%2015314!5e0!3m2!1ses!2spe!4v1752091435444!5m2!1ses!2spe"
                        width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"
                        referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </section>

            <section id="itinerario-section">

                <h2 data-i18n="itinerary_title">Itinerario del Evento</h2>
                <h1 style="text-align: center;">Dia del evento: 01/11/2025</h1>

                <div class="timeline-container">
                    <div class="timeline-bar">
                        <div class="timeline-fill" id="timelineFill"></div>
                    </div>
                    <div class="timeline">
                        <div class="evento">
                            <h3><i class="fas fa-door-open"></i> <span data-i18n="event_1">Recepción</span></h3>
                            <span class="hora">17:00</span>
                            <p data-i18n="event_1_desc">Bienvenida a los invitados, zona de fotos y ambientación
                                inicial.</p>
                        </div>
                        <div class="evento">
                            <h3><i class="fas fa-star"></i> <span data-i18n="event_2">Presentación</span></h3>
                            <span class="hora">17:30</span>
                            <p data-i18n="event_2_desc">Ingreso de la quinceañera y palabras de agradecimiento.</p>
                        </div>
                        <div class="evento">
                            <h3><i class="fas fa-music"></i> <span data-i18n="event_3">Baile</span></h3>
                            <span class="hora">18:00</span>
                            <p data-i18n="event_3_desc">Vals de la quinceañera y apertura de la pista de baile.</p>
                        </div>
                        <div class="evento">
                            <h3><i class="fas fa-utensils"></i> <span data-i18n="event_4">Cena</span></h3>
                            <span class="hora">19:00</span>
                            <p data-i18n="event_4_desc">Delicioso buffet con variedad de platillos para todos los
                                gustos.</p>
                        </div>
                        <div class="evento">
                            <h3><i class="fas fa-glass-cheers"></i> <span data-i18n="event_5">Fiesta</span></h3>
                            <span class="hora">20:00 - 02:00</span>
                            <p data-i18n="event_5_desc">DJ en vivo, baile libre, show de luces y mucha diversión hasta
                                el cierre.</p>
                        </div>
                    </div>
                </div>
            </section>

            <section id="vestimenta-section">
                <h2 data-i18n="dress_code_title">Código de Vestimenta</h2>
                <div class="codigo-vestimenta">
                    <div class="vestimenta-item">
                        <div class="vestimenta-img"><i class="fas fa-crown"></i></div>
                        <h3 data-i18n="dress_code_1">Formal</h3>
                    </div>
                    <div class="vestimenta-item">
                        <div class="vestimenta-img"><i class="fas fa-palette"></i></div>
                        <h3 data-i18n="dress_code_2">Vestimenta de color Celeste no está permitida</h3>
                    </div>
                </div>
            </section>

            <section id="regalos-section">
                <div style="
                display: grid;
                place-content: center;
                margin-bottom: 20px;
                ">
                    <img src="regalo.svg" alt="" style="
                width: 100px;
                ">

                </div>
                <h2 data-i18n="gifts_title">Mesas de Regalos</h2>

                <p data-i18n="gifts_message">
                    Mi mayor alegría es compartir con la familia y amigos en este día tan especial. Si tu deseo es
                    hacerme un
                    presente, te agradeceré que este sea en
                    efectivo o transferencia.
                </p>
                <div style="display: grid;place-content: center;padding: 30px;">
                    <img src="foto.svg" alt="" style=" width: 200px;">
                    <br>
                    <p style="text-align: center;">813 858 3714</p>
                </div>
            </section>

            <section id="fotos-section">
                <h2 data-i18n="photos_title">Mis Fotos</h2>
                <div class="galeria">
                    <div class="foto-galeria">
                        <img src="fotos/1.jpeg" alt="">
                    </div>
                    <div class="foto-galeria">
                        <img src="fotos/2.jpeg" alt="">
                    </div>
                    <div class="foto-galeria">
                        <img src="fotos/3.jpeg" alt="">
                    </div>
                    <div class="foto-galeria">
                        <img src="fotos/4.jpeg" alt="">
                    </div>
                    <div class="foto-galeria">
                        <img src="fotos/5.jpeg" alt="">
                    </div>
                    <div class="foto-galeria">
                        <img src="fotos/6.jpeg" alt="">
                    </div>
                    <div class="foto-galeria">
                        <img src="fotos/7.jpeg" alt="">
                    </div>
                    <div class="foto-galeria">
                        <img src="fotos/1.jpeg" alt="">
                    </div>
                </div>
            </section>

            <section id="confirmacion-section">
                <h2 data-i18n="confirmation_title">Confirmación de Asistencia</h2>
                <p style="text-align:center;margin-bottom:20px;font-size:1rem;" data-i18n="pass_info">Pase válido para 1
                    persona</p>
                <div class="formulario">
                    <form id="confirmacionForm" method="POST">
                        <div class="form-group">
                            <label for="nombre" data-i18n="full_name">Nombre completo</label>
                            <input type="text" id="nombre" name="nombre" required
                                data-i18n-placeholder="name_placeholder" placeholder="Tu nombre completo">
                        </div>

                        <div class="form-group">
                            <label for="email" data-i18n="email">Correo electrónico</label>
                            <input type="email" id="email" name="email" required
                                data-i18n-placeholder="email_placeholder" placeholder="tu@email.com">
                        </div>

                        <div class="form-group">
                            <label data-i18n="confirmation">Confirmo que:</label>
                            <div class="asistencia-options">
                                <div class="asistencia-option">
                                    <input type="radio" id="asistire" name="asistencia" value="asistire" required>
                                    <label for="asistire" data-i18n="will_attend">Asistiré con gusto</label>
                                </div>
                                <div class="asistencia-option">
                                    <input type="radio" id="no-asistire" name="asistencia" value="no-asistire">
                                    <label for="no-asistire" data-i18n="wont_attend">No podré asistir</label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="mensaje" data-i18n="message_label">Mensaje para Briahna Portal
                                (opcional)</label>
                            <textarea id="mensaje" name="mensaje" data-i18n-placeholder="message_placeholder"
                                placeholder="Escribe un mensaje especial..."></textarea>
                        </div>

                        <button type="submit" class="btn-enviar" data-i18n="send_button">Enviar Confirmación</button>
                    </form>
                </div>
            </section>
        </main>

        <footer>
            <p data-i18n="footer_1">¡Espero contar con tu presencia en este día tan especial para mí!</p>
            <p data-i18n="footer_2">Con todo mi cariño, Briahna Portal</p>
            <p>© 2024 - Mis XV Años - Todos los derechos reservados</p>
        </footer>
    </div>

    <audio id="audioPlayer" loop>
        <source src="audio.mp3" type="audio/mpeg">
    </audio>

    <script>
        // Traducciones personalizadas
        const translations = {
            es: {
                "title": "Mis XV Años",
                "subtitle": "Te invito a celebrar conmigo este momento único e inolvidable",
                "song_title": "Canción: Princesa - Joan Sebastian",
                "countdown_text": "¡Solo faltan!",
                "days": "Días",
                "hours": "Horas",
                "minutes": "Minutos",
                "seconds": "Segundos",
                "message_title": "Un Mensaje Especial",
                "message_1": "¡Queridos amigos y familiares!",
                "message_2": "Hace 15 años, nació una bella princesa, enviada a nosotros por Dios para ser criada y moldeada en nuestra posesión más preciada. Los momentos que más esperas en la vida son a menudo soñados, imaginados y tienen que ser construidos. Hoy puedo decirles que uno de nuestros sueños se ha hecho realidad, y lo más importante para mí es que celebren conmigo. ¡en este día tan especial!",
                "message_3": "Con todo mi cariño,",
                "blessing_title": "Con la Bendición de...",
                "father": "Mi Papá",
                "mother": "Mi Mamá",
                "godparents": "Mis Padrinos",
                "event_details": "Detalles del Evento",
                "date": "Fecha",
                "date_value": "Sábado, 15 de Diciembre de 2024",
                "time": "Hora",
                "ceremony_time": "Ceremonia: 18:00 hrs",
                "reception_time": "Recepción: 20:00 hrs",
                "ceremony": "Ceremonia Religiosa",
                "ceremony_location": "Parroquia de Nuestra Señora de Guadalupe",
                "ceremony_address": "Av. Reforma #456, Ciudad",
                "reception": "Recepción",
                "reception_location": "Salón de Eventos \"Jardines del Cielo\"",
                "reception_address": "Av. Siempre Viva #123, Ciudad",
                "location_title": "Ubicación",
                "itinerary_title": "Itinerario del Evento",
                "event_1": "Recepción",
                "event_1_desc": "Bienvenida a los invitados, zona de fotos y ambientación inicial.",
                "event_2": "Presentación",
                "event_2_desc": "Ingreso de la quinceañera y palabras de agradecimiento.",
                "event_3": "Baile",
                "event_3_desc": "Vals de la quinceañera y apertura de la pista de baile.",
                "event_4": "Cena",
                "event_4_desc": "Delicioso buffet con variedad de platillos para todos los gustos.",
                "event_5": "Fiesta",
                "event_5_desc": "DJ en vivo, baile libre, show de luces y mucha diversión hasta el cierre.",
                "dress_code_title": "Código de Vestimenta",
                "dress_code_1": "Formal",
                "dress_code_2": "Vestimenta de color Celeste no está permitida",
                "gifts_title": "Mesas de Regalos",
                "gifts_message": "Mi mayor alegría es compartir con la familia y amigos en este día tan especial. Si tu deseo es hacerme un presente, te agradeceré que este sea en efectivo o transferencia.",
                "photos_title": "Mis Fotos",
                "confirmation_title": "Confirmación de Asistencia",
                "pass_info": "Pase válido para 1 persona",
                "full_name": "Nombre completo",
                "name_placeholder": "Tu nombre completo",
                "email": "Correo electrónico",
                "email_placeholder": "tu@email.com",
                "confirmation": "Confirmo que:",
                "will_attend": "Asistiré con gusto",
                "wont_attend": "No podré asistir",
                "message_label": "Mensaje para Briahna Portal (opcional)",
                "message_placeholder": "Escribe un mensaje especial...",
                "send_button": "Enviar Confirmación",
                "footer_1": "¡Espero contar con tu presencia en este día tan especial para mí!",
                "footer_2": "Con todo mi cariño, Briahna Portal"
            },
            en: {
                "title": "My 15th Birthday",
                "subtitle": "I invite you to celebrate this unique and unforgettable moment with me",
                "song_title": "Song: Princesa - Joan Sebastian",
                "countdown_text": "Only",
                "days": "Days",
                "hours": "Hours",
                "minutes": "Minutes",
                "seconds": "Seconds",
                "message_title": "A Special Message",
                "message_1": "Dear friends and family!",
                "message_2": "Fifteen years ago, a beautiful princess was born, sent to us by God to be raised and shaped into our most precious possession. The moments you most look forward to in life are often dreamed, imagined, and must be built. Today I can tell you that one of our dreams has come true, and the most important thing for me is that you celebrate with me on this very special day!",
                "message_3": "With all my love,",
                "blessing_title": "With the Blessing of...",
                "father": "My Father",
                "mother": "My Mother",
                "godparents": "My Godparents",
                "event_details": "Event Details",
                "date": "Date",
                "date_value": "Saturday, December 15, 2024",
                "time": "Time",
                "ceremony_time": "Ceremony: 6:00 PM",
                "reception_time": "Reception: 8:00 PM",
                "ceremony": "Religious Ceremony",
                "ceremony_location": "Our Lady of Guadalupe Parish",
                "ceremony_address": "456 Reforma Ave, City",
                "reception": "Reception",
                "reception_location": "\"Heaven Gardens\" Event Hall",
                "reception_address": "123 Evergreen Ave, City",
                "location_title": "Location",
                "itinerary_title": "Event Itinerary",
                "event_1": "Reception",
                "event_1_desc": "Guest welcome, photo area and initial ambiance.",
                "event_2": "Presentation",
                "event_2_desc": "Entrance of the quinceañera and words of gratitude.",
                "event_3": "Dance",
                "event_3_desc": "Quinceañera waltz and dance floor opening.",
                "event_4": "Dinner",
                "event_4_desc": "Delicious buffet with a variety of dishes for all tastes.",
                "event_5": "Party",
                "event_5_desc": "Live DJ, free dance, light show and lots of fun until closing.",
                "dress_code_title": "Dress Code",
                "dress_code_1": "Formal",
                "dress_code_2": "Light blue clothing is not allowed",
                "gifts_title": "Gift Registries",
                "gifts_message": "My greatest joy is to share with family and friends on this special day. If you wish to give me a gift, I would appreciate it if it were cash or a bank transfer.",
                "photos_title": "My Photos",
                "confirmation_title": "RSVP",
                "pass_info": "Pass valid for 1 person",
                "full_name": "Full name",
                "name_placeholder": "Your full name",
                "email": "Email address",
                "email_placeholder": "your@email.com",
                "confirmation": "I confirm that:",
                "will_attend": "I will gladly attend",
                "wont_attend": "I won't be able to attend",
                "message_label": "Message for Briahna Portal (optional)",
                "message_placeholder": "Write a special message...",
                "send_button": "Send Confirmation",
                "footer_1": "I hope to have your presence on this very special day for me!",
                "footer_2": "With all my love, Briahna Portal"
            },
            fr: {
                "title": "Mes 15 Ans",
                "subtitle": "Je vous invite à célébrer avec moi ce moment unique et inoubliable",
                "song_title": "Chanson: Princesa - Joan Sebastian",
                "countdown_text": "Plus que",
                "days": "Jours",
                "hours": "Heures",
                "minutes": "Minutes",
                "seconds": "Secondes",
                "message_title": "Un Message Spécial",
                "message_1": "Chers amis et famille !",
                "message_2": "Il y a quinze ans, une belle princesse est née, envoyée par Dieu pour être élevée et façonnée en notre possession la plus précieuse. Les moments que vous attendez le plus dans la vie sont souvent rêvés, imaginés et doivent être construits. Aujourd'hui, je peux vous dire que l'un de nos rêves est devenu réalité, et la chose la plus importante pour moi est que vous célébriez avec moi en ce jour très spécial !",
                "message_3": "Avec tout mon amour,",
                "blessing_title": "Avec la Bénédiction de...",
                "father": "Mon Père",
                "mother": "Ma Mère",
                "godparents": "Mes Parrains",
                "event_details": "Détails de l'Événement",
                "date": "Date",
                "date_value": "Samedi 15 Décembre 2024",
                "time": "Heure",
                "ceremony_time": "Cérémonie: 18:00",
                "reception_time": "Réception: 20:00",
                "ceremony": "Cérémonie Religieuse",
                "ceremony_location": "Paroisse Notre-Dame de Guadalupe",
                "ceremony_address": "456 Av. Reforma, Ville",
                "reception": "Réception",
                "reception_location": "Salle d'Événements \"Jardins du Ciel\"",
                "reception_address": "123 Av. Toujours Vivante, Ville",
                "location_title": "Emplacement",
                "itinerary_title": "Programme de l'Événement",
                "event_1": "Accueil",
                "event_1_desc": "Accueil des invités, zone photo et ambiance initiale.",
                "event_2": "Présentation",
                "event_2_desc": "Entrée de la quinceañera et mots de remerciement.",
                "event_3": "Danse",
                "event_3_desc": "Valse de la quinceañera et ouverture de la piste de danse.",
                "event_4": "Dîner",
                "event_4_desc": "Délicieux buffet avec une variété de plats pour tous les goûts.",
                "event_5": "Fête",
                "event_5_desc": "DJ en direct, danse libre, spectacle de lumières et beaucoup de plaisir jusqu'à la fermeture.",
                "dress_code_title": "Code Vestimentaire",
                "dress_code_1": "Formel",
                "dress_code_2": "Les vêtements bleu clair ne sont pas autorisés",
                "gifts_title": "Listes de Cadeaux",
                "gifts_message": "Ma plus grande joie est de partager avec ma famille et mes amis en ce jour spécial. Si vous souhaitez me faire un cadeau, je vous serais reconnaissant de le faire en espèces ou par virement bancaire.",
                "photos_title": "Mes Photos",
                "confirmation_title": "Confirmation de Présence",
                "pass_info": "Passe valable pour 1 personne",
                "full_name": "Nom complet",
                "name_placeholder": "Votre nom complet",
                "email": "Adresse e-mail",
                "email_placeholder": "votre@email.com",
                "confirmation": "Je confirme que:",
                "will_attend": "Je serai ravi d'assister",
                "wont_attend": "Je ne pourrai pas assister",
                "message_label": "Message pour Briahna Portal (optionnel)",
                "message_placeholder": "Écrivez un message spécial...",
                "send_button": "Envoyer la Confirmation",
                "footer_1": "J'espère vous compter parmi nous en ce jour si spécial pour moi !",
                "footer_2": "Avec tout mon amour, Briahna Portal"
            }
        };

        // Función para cambiar idioma
        function cambiarIdioma(lang) {
            // Actualizar elementos con data-i18n
            document.querySelectorAll('[data-i18n]').forEach(el => {
                const key = el.getAttribute('data-i18n');
                if (translations[lang][key]) {
                    el.textContent = translations[lang][key];
                }
            });

            // Actualizar placeholders
            document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
                const key = el.getAttribute('data-i18n-placeholder');
                if (translations[lang][key]) {
                    el.placeholder = translations[lang][key];
                }
            });

            // Actualizar botones de idioma
            document.querySelectorAll('.lang-btn').forEach(btn => {
                if (btn.getAttribute('data-lang') === lang) {
                    btn.classList.add('active');
                } else {
                    btn.classList.remove('active');
                }
            });

            // Actualizar fecha según idioma
            const eventDate = new Date('December 15, 2024');
            const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
            document.getElementById('event-date').textContent = eventDate.toLocaleDateString(lang, options);
        }

        // Event listeners para botones de idioma
        document.querySelectorAll('.lang-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const lang = btn.getAttribute('data-lang');
                cambiarIdioma(lang);
            });
        });

        // Inicializar con español
        cambiarIdioma('es');

        // El resto de tu código JavaScript existente
        // Contador regresivo
        const fechaEvento = new Date('November 11, 2025 18:00:00').getTime();

        const actualizarContador = () => {
            const ahora = new Date().getTime();
            const diferencia = fechaEvento - ahora;

            if (diferencia > 0) {
                const dias = Math.floor(diferencia / (1000 * 60 * 60 * 24));
                const horas = Math.floor((diferencia % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const minutos = Math.floor((diferencia % (1000 * 60 * 60)) / (1000 * 60));
                const segundos = Math.floor((diferencia % (1000 * 60)) / 1000);

                document.getElementById('dias').innerText = dias.toString().padStart(2, '0');
                document.getElementById('horas').innerText = horas.toString().padStart(2, '0');
                document.getElementById('minutos').innerText = minutos.toString().padStart(2, '0');
                document.getElementById('segundos').innerText = segundos.toString().padStart(2, '0');
            } else {
                document.getElementById('contador-texto').innerText = "¡El evento ya comenzó!";
                document.querySelector('.tiempo').style.display = 'none';
            }
        };

        setInterval(actualizarContador, 1000);
        actualizarContador();

        // Reproductor de música
        const audioPlayer = document.getElementById('audioPlayer');
        const playBtn = document.getElementById('playBtn');
        const audioPlayerContainer = document.getElementById('audioPlayerContainer');
        let isPlaying = false;

        // Mostrar el reproductor después de un retraso
        setTimeout(() => {
            audioPlayerContainer.classList.add('visible');
        }, 3000);

        playBtn.addEventListener('click', () => {
            if (isPlaying) {
                audioPlayer.pause();
                playBtn.innerHTML = '<i class="fas fa-heart"></i>';
            } else {
                audioPlayer.play().catch(e => {
                    console.log("La reproducción automática fue bloqueada. Haga clic para iniciar.");
                });
                playBtn.innerHTML = '<i class="fas fa-pause"></i>';
            }
            isPlaying = !isPlaying;
        });

        // Formulario de confirmación
        document.getElementById('confirmacionForm').addEventListener('submit', function (e) {
            e.preventDefault();
            
            // Crear FormData y enviar con fetch
            const formData = new FormData(this);
            
            fetch('', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                // Mostrar alerta de éxito
                alert('¡Confirmación enviada con éxito!');
                this.reset();
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Hubo un error al enviar la confirmación');
            });
        });

        // Animación de la barra de tiempo
        function animarBarraTiempo() {
            const eventos = document.querySelectorAll('.evento');
            const barraFill = document.getElementById('timelineFill');
            const alturaTotal = document.querySelector('.timeline').offsetHeight;
            const alturaVentana = window.innerHeight;

            eventos.forEach((evento, index) => {
                const posicion = evento.getBoundingClientRect().top;
                if (posicion < alturaVentana * 0.8) {
                    evento.classList.add('visible');

                    // Calcular progreso para la barra de tiempo
                    const progreso = (index + 1) / eventos.length;
                    barraFill.style.height = `${progreso * 100}%`;
                }
            });
        }

        // Observador de intersección para animaciones
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');

                    // Animación especial para la sección de tiempo
                    if (entry.target.id === 'itinerario-section') {
                        animarBarraTiempo();
                    }
                }
            });
        }, {
            threshold: 0.1
        });

        // Observar todas las secciones
        document.querySelectorAll('section').forEach(section => {
            observer.observe(section);
        });

        // Llamar a la animación de la barra de tiempo al cargar y al hacer scroll
        window.addEventListener('scroll', animarBarraTiempo);
        window.addEventListener('load', animarBarraTiempo);

        // Cambiar texto del contador cuando faltan pocos días
        window.addEventListener('load', () => {
            const ahora = new Date();
            const diasFaltantes = Math.ceil((fechaEvento - ahora) / (1000 * 60 * 60 * 24));

            if (diasFaltantes <= 7) {
                document.getElementById('contador-texto').innerText = "¡Ya casi es el gran día!";
            } else if (diasFaltantes <= 30) {
                document.getElementById('contador-texto').innerText = "¡Falta poco para la celebración!";
            }
        });
    </script>
</body>
</html>